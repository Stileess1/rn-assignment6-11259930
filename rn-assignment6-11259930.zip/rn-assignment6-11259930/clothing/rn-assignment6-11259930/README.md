# rn-assignment6-11259930

Home
Path: screens/home.js

The Home screen serves as the main entry point of the app. It provides an overview of the available products and allows users to navigate to the Checkout screen.

Checkout Screen
Path: screens/checkout.js

The Checkout screen allows users to review their selected products and proceed with the purchase process.

Navigation
The app uses React Navigation to handle navigation between screens.

navigationService.js
Path: navigationService.js

This file contains navigation utility functions to navigate between screens programmatically.

appnavigator.js
Path: appnavigator.js

This file sets up the main navigation structure of the app, including the stack navigator that handles the transition between the Home and Checkout screens.

App.js
Path: App.js

This is the entry point of the app, which initializes the navigation and renders the main navigation structure.
![homeScreenshot1](./clothing/src/screens/images/homeScreenshot1.jpg)
![homeScreenshot2](./clothing/src/screens/images/homeScreenshot2.jpg)
![checkoutScreenshot](./clothing/src/screens/images/checkoutScreenshot.jpg)
